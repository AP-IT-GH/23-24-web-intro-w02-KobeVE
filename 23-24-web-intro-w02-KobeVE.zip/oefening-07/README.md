# 💻 02. HTML - basis > oefening 07

## 🛠️ opdrachten

### `index.html` maken

- [ ] Maak een nieuw bestand genaamd `index.html` aan in deze map.
- [ ] Open het bestand.

### voorbeeld namaken

- [ ] Kopieer de code uit voorgaande oefening.
- [ ] Zorg er nu voor dat de afbeelding een link is waar je op kan klikken. De link moet verwijzen naar de url: https://www.ap.be

![Alt text](image.png)
